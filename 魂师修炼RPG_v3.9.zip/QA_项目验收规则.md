# 魂师修炼RPG｜项目验收规则

> **文件职责：** 只定义治理、职责分立、路由、状态边界与正式发布的 PASS 条件。
>
> **权威范围：** “什么状态算通过/失败”；不拥有被验收业务的实现规则。
>
> **不负责：** 不复制任何业务常量、公式、固定时长、价格、门槛、菜单或篇章实现。
>
> **读取策略：** 仅文件维护 / QA route 使用。

## Incremental QA

目标修改后至少检查：

1. 文件可解析、无截断。
2. 文件职责与 manifest 登记一致。
3. 目标领域只有一个业务 owner；其他消费者只保留引用、占位符或编排语义。
4. 直接消费者和 route 引用仍有效。
5. 不存在被删除文件、旧接口、别名、补丁、施工史或无消费者容器残留。
6. UI 不保存机械常量；交互层不保存机械公式；Kernel 不保存领域常量；状态 schema 不保存可由领域 owner 读取的重复业务常量。
7. 普通运行最多修改 `runtime_working_state`；外部 checkpoint 只由 manifest 授权的持久化事务产生。
8. 受影响的 manifest、派生运输说明和 QA 结构已经同步。
9. 若修改大型内容 owner（如伙伴篇章库），其 owner 自己声明的 mandatory-card 结构在全部受管对象上仍完整覆盖；不得只修单章而让同一 owner 的结构约束出现半套状态。
10. 若修改选择型内容，抽查相邻与全章选择语义没有重复询问同一关系问题；后续节点确实消费前文结果，而不是换措辞重问。
11. 若内容 owner 声明记忆画面/CG锚点，检查其为可观察场面而非关系总结句，并且不同局部分流不会通过删掉该场面来缩短章节。
12. 若本轮实现或修改CG大厅，检查主页面入口、只读边界、未解锁隐藏策略与“列表内直接展示完整画面描写、不存在二级查看/场景回放/来源或获得资料页”的UI约束已经同步。

## Global QA

以下全部 PASS 才可正式交付：

### A. 治理与成员
1. 治理入口唯一：索引 + manifest。
2. `manifest.current.*`、route owner/source 和 external source 引用全部可解析。
3. manifest 登记成员集合与正式 ZIP 成员集合一致。
4. 正式包无备份、补丁、测试、构建稿、施工史和未登记成员。
5. manifest 内容成员 SHA/bytes 与实际文件一致；manifest self-hash 不形成自指。

### B. 单一职责
6. 每个业务规则只能有一个 owner。
7. 非 owner 文件不得复制该规则的固定数字、公式、门槛、完整表格或判定文本；只允许 pointer、placeholder、调用顺序与玩家可见展示槽位。
8. 不存在仅靠 current 指针存活、却没有独立职责或真实消费者的“总控/汇总第二主源”。
9. 玩家帮助内容只有一个交互 owner；不另维护同步副本。
10. UI 模板只拥有字段/顺序/排版，所有业务值在运行时从领域 owner 注入。CG大厅若存在，同样不得自存解锁算法或奖励规则。
11. Kernel 只拥有编排，不重新实现战斗、成长、经济、世界、篇章或状态规则。
12. QA 本身不携带业务常量，只验证 owner/consumer 边界与结构。

### C. 路由
13. 控制事务先于普通游戏 route；控制事务可直接 dispatch 到 route 或 Skill。
14. 所有 `ordinary_gameplay` route 必须且只能在 `manifest.interaction_route_activation` 出现一次，最终有且仅有一个 fallback。
15. 非 support route 必须存在真实入口：route 型 control intent、启动入口、ordinary activation、`delegates_to` 或 current/项目入口消费者；禁止孤儿 route。Skill 型 control intent 不要求也不得保留同职责空壳 route。
16. 过宽 route 必须拆分到能够对应单一主 owner；嵌套事务使用 `delegates_to`，不得靠永久扩充 source 形成万能 route。
17. 每个常见用户意图至少有一个明确 dispatcher；route 必须有 owner、最小 source、access policy 与 state access，Skill 必须有唯一名称/operation 且不得与同职责 route 双持。
18. 大型 DM ONLY 文件仅按对象/章节/节点选择性读取。
19. BOOT 只读取 manifest 启动切片，不无条件注入完整注册表。

### D. 状态
20. `12` 只拥有 schema、恢复/迁移、原子提交与持久化协议，不保存某次冒险当前值。
21. `latest_save` 是逻辑外部源；选择算法只在 manifest 登记，恢复协议由 `12` 消费。
22. 普通游戏 route 不原地改写已有 checkpoint。
23. 旧兼容字段只在仍有合法恢复/迁移消费者时保留；否则必须清除。
24. 序列化去冗余不得删除仍承担防重复或连续性职责的数据。

### E. 发布
25. release 只由 manifest 维护；Markdown 不复制当前 release。
26. 正式发布成品必须已通过 Global QA，且最终 ZIP 重开后成员、JSON、bytes/SHA 与 manifest 一致；本文件不规定外部维护 Skill 的执行顺序。
27. 若本轮未获状态迁移或存档授权，不得为了运行包整理制造新的 `STATE_REV`。

## 存档迁移 QA

只有明确执行 `STATE_MIGRATION` 时追加检查：

1. 来源 checkpoint 合法且可解析。
2. 新 revision 与目标 schema/runtime binding 正确。
3. 除迁移协议明确允许的结构/确定性纠错外，既成游戏事实没有变化。
4. 防重复与已结算标记保持语义等价。
5. 新 ZIP 从磁盘重开后成员和完整状态可读取。

## 版本号 QA

1. 正式运行包使用两段式 `MAJOR.MINOR`。
2. 用户未明确要求主版本升级时，只递增 `MINOR`。
3. manifest `release` 与正式包名属于同一次提交。


## 章节分片与选择语义专项 QA

- 45个 `CHAPTER_ID` 必须在 manifest `companion_episode_files` 中一对一映射到45个不同单章文件；不得缺失、重复或一章指向总库。
- `DM_ONLY_C00_伙伴篇章库.md` 只允许保存通用规则、公开导航索引和关系门，不得重新塞回任一完整故事卡。
- `companion_episode` route 每次运行最多解析并读取 **1个** `DM_ONLY_C10_伙伴篇章/*.md`；继续篇章优先由 `ACTIVE_EPISODE_ID` 直接命中，不扫描目录。
- 每个单章文件必须恰有8个不同 `CHOICE01..08` 语义职责；四个固定场景必须用两个不同标签显式写出，禁止无标签 `CHOICE01–02：泛化描述`。
- 相邻选择不得复问同一关系规则；CG、高理解回报、低分仍有戏、标题回收与角色新信息必须存在且能由章内具体事件执行。
