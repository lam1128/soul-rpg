# 魂师修炼RPG｜文档索引与版本状态

> 状态：ACTIVE
>
> **唯一治理入口：** 本文件 + `魂师修炼RPG_manifest.json`。
>
> **文件职责：** 规定治理顺序、单一职责、墓碑策略、项目维护、版本与发布纪律。
>
> **权威范围：** 人类可读治理原则；当前 release、正式成员、current 指针、route、Skill dispatcher、access policy、control intent、外部源、state model、freeze 与 SHA 均由 manifest 唯一机器登记。
>
> **不负责：** 不定义战斗、世界、剧情、人物、经济、UI、状态 schema 或某次冒险的当前具体值。
>
> **读取策略：** `BOOT`，只读取启动与治理所需段落。

## 1. 治理顺序

任何新窗口先：

`本索引 → manifest启动切片 → manifest.current.startup_router_fast_entry → manifest.current.control_intent_pre_router → 当前候选recognition owner`

控制事务未命中时，才进入普通游戏启动与 `manifest.interaction_route_activation`。每条新的用户主动消息都重新经过 control pre-router；不得靠聊天记忆或上轮 route 永久绑定当前事务。

专用项目外层入口读取 `manifest.current.project_entry_protocol`，但项目级说明不得复制或覆盖包内业务主源。

## 2. 单一职责与主源

- 一个职责只有一个 owner。
- manifest 为每个正式成员登记 `role / authority / write_owner / default_access`。
- 非 owner 文件只能保留逻辑指针、调用顺序、占位符、输入/输出槽位与最小消费说明。
- **禁止消费者复制 owner 的固定数字、公式、门槛、完整表格、固定时长、价格、篇章算法或判定文本。**
- UI 只拥有展示结构；README 只负责运输/部署；QA 只定义 PASS 条件；Runtime Kernel 只负责编排；交互文件不维护第二套路由表。
- `12_状态存档.md` 只拥有状态 schema、恢复、迁移、运行提交与导出协议，不保存当前冒险实例值，也不复制领域业务常量。

发现重复业务规则时，删除非 owner 副本并改成指针；不得长期依赖“冲突时听谁的”容忍第二套实现。

## 3. 状态模型

状态模型机器注册只读取 `manifest.state_model`；字段生命周期、恢复、迁移、运行提交与导出语义只读取 `12_状态存档.md`。

本索引只保留治理不变量：

- 会话工作态与正式 checkpoint 必须分层；
- 已有 ZIP 不得原地篡改；
- 未获持久化授权的普通运行不得制造新 revision；
- 项目整理、帮助、查看或游戏外讨论不得自动推进游戏世界。

## 4. 读取与状态访问

可用读取策略及精确定义只读取 `manifest.topic_route_access_policies`；可用状态访问等级及精确定义只读取 `manifest.state_access_levels`。本索引不维护第二套枚举说明。

治理原则：**先确认事务及其 dispatcher（route 或 Skill），再读取最小必要来源；来源不足才扩读。读取静态主源不等于拥有写权限。**

`DM_ONLY_C00_伙伴篇章库.md` 现在是小型篇章索引/通用规则 owner；45章正文位于 `DM_ONLY_C10_伙伴篇章/`。进入或继续篇章时必须通过 manifest `companion_episode_files[CHAPTER_ID]` 只读取一个单章文件，严禁遍历/批量加载单章目录。

## 5. 路由纪律

- control intent 的清单、优先级、recognition owner、recognition sections 与 dispatcher（route/Skill）映射只存在于 `manifest.control_intents`。
- 普通游戏 route 的匹配顺序和 activation 条件只存在于 `manifest.interaction_route_activation`。
- `topic_routes` 只登记仍由 route 执行的事务；Skill 接管的复杂控制事务不得保留同职责空壳 route。
- 一个普通 route 应有一个主 owner；跨领域子事务使用 `delegates_to` 或条件 source，不建立万能 route。
- 没有 control intent、启动入口、ordinary activation、delegates 或 current/项目入口消费者的 route 视为孤儿，应删除或接入真实入口；已迁移到 Skill 的旧 route 直接删除。

## 6. 墓碑与正式包卫生

正式包不保留：

- 已废弃规则；
- 无消费者旧接口/旧字段；
- `_old / _backup / final_final`；
- 修复过程稿、测试文件、已消费 patch/handoff；
- 构建过程说明；
- 仅用于讲述旧版本历史的赛博墓碑；
- manifest 未登记成员。

删除功能必须沿：
`主源 → 别名/旧接口 → 消费者 → manifest引用 → route → 派生视图 → 测试/临时残留`
闭环清理。

仍被当前恢复/迁移流程真实消费的历史 checkpoint 兼容规则属于运行能力，不视为墓碑；失去消费者后必须删除。

## 7. 文件维护与 QA

`PROJECT_CONFIG_CONTROL` 的 recognition 语义由本节拥有：用户明确讨论或要求修改游戏外项目设定、规则、文件、治理结构、检查、清理、打包或发布时，属于项目配置控制事务；该识别本身不推进游戏世界。

项目维护事务直接由 manifest 登记的外部 Skill 执行；运行包只保存识别语义、业务 owner 与 PASS 标准，不保存该 Skill 的执行步骤或第二套维护流程。

升级 Global QA 的触发条件只读取 `manifest.qa.global_required_on_conditions`；具体 PASS 条件只读取 `QA_项目验收规则.md`。本索引不维护第二套 QA 条件表。

## 8. 发布与版本

当前 release 只读取 `manifest.release`，采用两段式 `MAJOR.MINOR`。

- 默认规则调整、体验修正、内容修订、治理清理与平衡修改只递增 `MINOR`。
- 只有用户明确指定新功能/大版本或要求升级主版本时才递增 `MAJOR` 并把 `MINOR` 归零。
- 用户未明确要求升主版本时，禁止自行跨 MAJOR。
- 正式 Markdown 成员不重复写当前 release；成员身份由 manifest registry + SHA 确认。
- 运行包 release 与存档 `STATE_REV` 是独立版本对象。

正式发布的通过条件只读取 `QA_项目验收规则.md`；具体执行顺序由外部项目维护 Skill 独占，不在运行包重复维护。

## 9. 当前结构约束

- manifest 是唯一机器注册表。
- startup fast entry 与 control pre-router 是正式启动/控制入口；复杂项目维护和存档事务可由 manifest 直接 dispatch 到 Skill。
- `latest_save` 是逻辑外部源，不是硬编码存档文件名。
- README 与专用项目入口协议不复制业务实现。
- freeze 集合只认 manifest；未登记即不视为冻结。
