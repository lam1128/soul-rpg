# 魂师修炼RPG｜Startup Router Fast Entry

> **文件职责：** 新窗口的极小启动入口，只决定下一步读取什么。
>
> **权威范围：** 启动顺序与“禁止无条件全文加载”的快速门。
>
> **不负责：** 不执行存档选择、状态恢复、结算、业务判断或写入。
>
> **读取策略：** `BOOT`。

## 1. 新窗口顺序

`最高版本治理索引`
→ `manifest 启动切片`
→ `manifest.current.startup_router_fast_entry`
→ `manifest.current.control_intent_pre_router`
→ `manifest.control_intents.<candidate>.recognition_owner`。

fast exception 是否存在、指向哪里，只读取 manifest 当前登记；本文件不写死当前值。

## 2. manifest 启动切片

BOOT 只解析启动必需键：

- `project / release / status`
- `current`
- `fast_exceptions`
- `control_intents`
- `external_sources.latest_save` 的入口元数据

完整 `files / topic_routes / interaction_route_activation` 仍是机器权威，但只在对应事务确认后取当前需要的条目。机械成员/SHA扫描不等于把全部注册表注入运行上下文。

## 3. 状态入口

- “继续游戏 / 继续 / 恢复游戏”进入 `LOAD_SAVE` 候选。
- 新窗口无活动工作态但输入明确游戏内行动时，若存在合法 `latest_save`，先按 `LOAD_SAVE` 恢复再处理行动。
- `latest_save` 的候选合法性、排序与冲突失败规则只读取 `manifest.external_sources.latest_save` 与 `12` 的恢复协议，本文件不复制选择算法。
- 无合法 checkpoint 时不得依赖聊天记忆重建状态；只有明确新游戏意图才进入 `NEW_GAME`。

## 4. 禁止事项

- 不得在识别意图前全文读取全部游戏文件。
- 不得启动时加载大型 DM ONLY 数据库。
- recognition 只决定“去哪里”，不代表事务已经执行成功。
- 不得把 `12_状态存档.md` 当某次冒险的数据文件。
- 不得原地修改已有 checkpoint ZIP。
- 未确认控制事务时才进入普通游戏链。
